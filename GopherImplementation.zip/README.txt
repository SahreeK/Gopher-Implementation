A simple Gopher site by Cody Bohlman, Joe Burson, and Sahree Kasper for CS 331: Computer Networks, at Carleton College.

This site has a section about animals and a section of bad jokes.